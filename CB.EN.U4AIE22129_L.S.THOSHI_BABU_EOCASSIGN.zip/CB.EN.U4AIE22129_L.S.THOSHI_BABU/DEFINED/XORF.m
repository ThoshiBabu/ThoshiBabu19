function z=XORF(a,b)
%FUNCTION CREATION
if (a==1||a==0 && b==1||b==0)
    s=NOTF(a);
    d=NOTF(b);            % WE KNOW THAT ACCORDING TO THE TRUTH TABLE THE 
    f=ANDF(s,b);          % FORMULA IS A'B + AB'
    g=ANDF(d,a);          % THATS WHY WE USE 2 NOT GATES 2 AND GATES AND 1 OR GATE
    z=ORF(f,g);
else
    z=("invalid");
end



