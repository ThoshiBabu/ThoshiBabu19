function z=NANDF(a,b)
if (a==1||a==0 && b==1||b==0)%FUNCTION CREATION
s = ANDF(a,b);           %NAND FUNCTION IS BASICALLY NOT(AND)
z = NOTF(s);
else
    z=("invalid");
end