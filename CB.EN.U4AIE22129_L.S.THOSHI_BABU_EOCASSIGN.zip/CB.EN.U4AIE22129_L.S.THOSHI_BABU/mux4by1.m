function mux4=mux4by1(s0,s1,d0,d1,d2,d3)
mux4=mux2by1(s0,mux2by1(s0,d0,d1),mux2by1(s1,d2,d3))
end

