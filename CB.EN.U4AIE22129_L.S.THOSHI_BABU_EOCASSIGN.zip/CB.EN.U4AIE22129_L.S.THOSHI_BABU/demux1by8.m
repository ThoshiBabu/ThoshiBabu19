function z=demux1by8(in,s3,s2,s1)
x1=ANDF(ANDF(ANDF(NOTF(s3),NOTF(s2)),NOTF(s1)),in);
x2=ANDF(ANDF(ANDF(NOTF(s3),NOTF(s2)),s1),in);
x3=ANDF(ANDF(ANDF(NOTF(s3),s2),NOTF(s1)),in);
x4=ANDF(ANDF(ANDF(NOTF(s3),s2),s1),in);
x5=ANDF(ANDF(ANDF(s3,NOTF(s2)),NOTF(s1)),in);
x6=ANDF(ANDF(ANDF(s3,NOTF(s2)),s1),in);
x7=ANDF(ANDF(ANDF(s3,s2),NOTF(s1)),in);
x8=ANDF(ANDF(ANDF(s3,s2),s1),in);
z=[x1,x2,x3,x4,x5,x6,x7,x8];
end