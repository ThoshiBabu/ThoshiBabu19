function MUX=mux2by1(s0,d0,d1)
MUX=ORF(ANDF(NOTF(s0),d0),ANDF(s0,d1));
end