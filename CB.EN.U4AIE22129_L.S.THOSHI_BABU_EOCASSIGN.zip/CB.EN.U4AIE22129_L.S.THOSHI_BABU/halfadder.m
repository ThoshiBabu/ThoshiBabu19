function [hf,hfcarry]=halfaddersumandcarry(a,b)
hf=XORF(a,b)
hfcarry=ANDF(a,b)
disp([hf,hfcarry])
end